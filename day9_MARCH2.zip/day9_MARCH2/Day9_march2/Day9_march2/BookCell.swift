//
//  BookCell.swift
//  Day9_march2
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 Prabhjot. All rights reserved.
//

import UIKit

class BookCell: UICollectionViewCell {
   
    
    @IBOutlet var imgBook: UIImageView!
    
    @IBOutlet var lblBookTitle: UILabel!
    
}
